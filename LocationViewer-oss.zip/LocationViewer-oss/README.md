# LocationViewer-oss

Location Viewer oss is simple geocode application, on Android 5.0.

## Feature

- Simple code.
  - Use Location Manager and Geocoder only.
- Kotlin.
- Android 5.0, over.

## Download

To use the Location Viewer without building on your PC, please check the link below.

[Store](https://play.google.com/store/apps/details?id=com.app.dr1009.addbu)

### Notice
Store version (Location Viewer, not Location Viewer oss) includes advertisements and so on.

## Licence

MIT

